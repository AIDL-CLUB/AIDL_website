const data = [
    {
        title: "Fr.CRIT, Vashi",
        stitle: "About Fr.CRIT, Vashi",
        desc: "Fr. C.R.I.T. has, within a short span of time, established itself as a leading engineering college in Mumbai University. Though its reputation rests mainly on the high quality, value-based technical education that it imparts, it has to its credit a verdant, well-maintained Campus and extensive facilities."
    },
    {
        title: "AIDL CLUB",
        stitle: "About Artificial Intelligence and Deep Learning Club",
        desc: "FCRIT-AIDL Club is a group of Staff and Students of Fr. C. Rodrigues Institute of Technology, Vashi, focusing mainly on activities related to Artificial Intelligence and Deep Learning. The idea is to spread awareness, encourage students, staff and industry professionals and inculcate enthusiasm to take up projects in this domain and solve real life problems of our society."
    },
    {
        title: "CLUB ACTIVITIES",
        stitle: "Events and Activities conducted by AIDL CLUB",
        desc:"We have conducted Online as well as Offline workshops related to Tensorflow, Python basics, AIML begineer level projects, concepts in DL and many more Competitions, Quizzes and Hackathons. And many more are on the way, so stay tuned..."    },
    {
        title: "About MEMBERSHIP",
        stitle: "How to become a member",
        desc: "	Its very simple, just click on the link given in membership section and fill a simple google form by paying a minimum amount and done. Welcome to AIDL club for learing new technologies and interesting stuff... "
    },
  
]

export default data